const section = document.getElementById('homeView');

export async function showHome(ctx) {
  ctx.showSection(section);
}