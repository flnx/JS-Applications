import { html } from '../lib.js';

// export const footer = () => html`<footer class="footer"><p>Created by SoftUni Delivery Team</p></footer>`;


