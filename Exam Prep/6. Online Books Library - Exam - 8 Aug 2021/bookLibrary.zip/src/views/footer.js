import { html } from '../lib.js';

export const footer = () => html` 
<footer id="site-footer">
  <p>@OnlineBooksLibrary</p>
</footer>`;
