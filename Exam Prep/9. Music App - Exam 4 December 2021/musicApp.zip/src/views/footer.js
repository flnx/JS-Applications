import { html } from '../lib.js';

export const footer = () => html` <footer>
  <div>&copy;SoftUni Team 2021. All rights reserved.</div>
</footer>`;
