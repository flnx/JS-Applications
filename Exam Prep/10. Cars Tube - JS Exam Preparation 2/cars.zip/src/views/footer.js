import { html } from '../lib.js';

export const footer = () => html` 
<footer>
  <p>&copy; All rights reserved</p>
</footer>`;
