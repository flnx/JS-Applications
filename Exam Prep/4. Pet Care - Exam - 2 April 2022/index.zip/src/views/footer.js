import { html } from "../lib.js";

export const footer = () => html`<footer>Pet Care 2022©</footer>`;