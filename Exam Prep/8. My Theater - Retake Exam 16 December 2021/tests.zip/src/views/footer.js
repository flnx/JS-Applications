import { html } from '../lib.js';

export const footer = () => html` 
<footer>
  <div>
    © 2021
    <h3>JS Application</h3>
  </div>
</footer>`;
